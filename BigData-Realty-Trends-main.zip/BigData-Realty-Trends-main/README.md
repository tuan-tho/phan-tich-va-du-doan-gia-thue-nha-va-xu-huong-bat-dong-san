# Big Data - Phân Tích và Dự Đoán Xu Hướng Bất Động Sản

## 📌 Giới Thiệu

### 🔹 Mô tả dự án
Dự án này nhằm phân tích và dự đoán xu hướng bất động sản bằng cách sử dụng **Big Data** và mô hình xử lý dữ liệu phân tán **MapReduce**. Với khối lượng dữ liệu lớn từ các nguồn như giao dịch nhà đất, giá bất động sản, dữ liệu dân số và xu hướng kinh tế, hệ thống sẽ giúp đưa ra những dự đoán chính xác về biến động giá nhà theo thời gian và khu vực.

### 🔹 Mục tiêu nghiên cứu
- Thu thập và xử lý dữ liệu bất động sản từ nhiều nguồn khác nhau.
- Áp dụng **MapReduce** để tối ưu hóa quá trình xử lý dữ liệu lớn.
- Xây dựng mô hình dự đoán xu hướng giá bất động sản dựa trên dữ liệu lịch sử.
- Đưa ra báo cáo trực quan về xu hướng giá nhà theo khu vực.

## 🏗️ Công Nghệ Sử Dụng
- **Hadoop & MapReduce**: Xử lý dữ liệu lớn trên hệ thống phân tán.
- **Python & Spark**: Tiền xử lý và phân tích dữ liệu.
- **Machine Learning**: Sử dụng các mô hình dự đoán giá bất động sản.
- **Kafka & HDFS**: Lưu trữ và xử lý dữ liệu thời gian thực.

## 📊 Kiến Trúc Hệ Thống
1. **Thu thập dữ liệu**: Crawl dữ liệu từ các trang web bất động sản, API chính phủ, dữ liệu GIS.
2. **Tiền xử lý dữ liệu**: Làm sạch dữ liệu, chuẩn hóa giá trị, loại bỏ ngoại lệ.
3. **Xử lý dữ liệu bằng MapReduce**:
   - **Mapper**: Phân chia dữ liệu theo từng khu vực, thời gian.
   - **Reducer**: Tổng hợp, tính toán giá trung bình, xu hướng.
4. **Dự đoán giá nhà**: Áp dụng mô hình học máy như **Random Forest, XGBoost** để dự đoán giá bất động sản.
5. **Trực quan hóa dữ liệu**: Dashboard hiển thị xu hướng thị trường.

## 🔬 Phương Pháp Luận
- **Phân tích thống kê**: Xác định các yếu tố ảnh hưởng đến giá bất động sản.
- **Xử lý song song với MapReduce**: Chia nhỏ dữ liệu để tối ưu tốc độ xử lý.
- **Đánh giá mô hình dự đoán**: Dùng **MAE, RMSE** để đo độ chính xác của mô hình.


## 📜 Tác Giả
📌 **Trịnh Văn Hào** - [Email: haotrinh142@gmail.com](mailto:haotrinh142@gmail.com)

---
🚀 **Dự án này nhằm phân tích và dự đoán giá bất động sản, hiểu cách vận hành và ưu điểm của việc sử dụng Mapreduce trong phân tích dữ liệu lớn.**
